#include <iostream>
#include <stack>
#include <string>
#include <sstream>
#include <cctype>

using namespace std;

// Function to check if the character is an operator
bool isOperator(char c) {
    return c == '+' || c == '-' || c == '*' || c == '/' || c == '%';
}

// Function to perform the operation based on the operator and operands
int performOperation(char operation, int operand1, int operand2) {
    switch (operation) {
        case '+': return operand1 + operand2;
        case '-': return operand1 - operand2;
        case '*': return operand1 * operand2;
        case '/': 
            if (operand2 == 0) {
                cout << "Error: Division by zero!" << endl;
                exit(1); // Exit if division by zero
            }
            return operand1 / operand2;
        case '%': return operand1 % operand2;
        default: 
            cout << "Unexpected operator encountered!" << endl;
            exit(1);
    }
}

// Function to evaluate a postfix expression
int evaluatePostfixExpression(const string &postfix) {
    stack<int> operandStack;
    stringstream ss(postfix);
    string token;
    
    while (ss >> token) {
        // If the token is an operand, push it to the stack
        if (isdigit(token[0])) {
            operandStack.push(stoi(token));
        }
        // If the token is an operator
        else if (isOperator(token[0])) {
            if (operandStack.size() < 2) {
                cout << "Expression is not well-formed!" << endl;
                return -1;
            }

            // Pop two operands from the stack
            int operand2 = operandStack.top(); operandStack.pop();
            int operand1 = operandStack.top(); operandStack.pop();

            // Perform the operation and push the result back to the stack
            int result = performOperation(token[0], operand1, operand2);
            operandStack.push(result);
        } else {
            cout << "Invalid character in expression: " << token << endl;
            return -1;
        }
    }

    // After processing the entire postfix expression, the stack should have only one element
    if (operandStack.size() == 1) {
        return operandStack.top(); // The final result
    } else {
        cout << "Expression is not well-formed!" << endl;
        return -1;
    }
}

int main() {
    string postfix1;
    std::getline(std::cin, postfix1);
    cout << "Result of expression '" << postfix1 << "' is " << evaluatePostfixExpression(postfix1) << endl;
    return 0;
}